#include<stdio.h>
#include<string.h>
#include<stdlib.h>

typedef struct multistruct
{
	int rowno;
	int colno;
	int val;
	
	struct multistruct *rp;
	struct multistruct *cp;
}Node;
Node *nodefunction(int row , int col , int data)
{
	Node *newnodefun = malloc(sizeof(Node));;
	//newnodefun=( Node *)malloc(sizeof( Node *));
	newnodefun->rowno =  row;
	newnodefun->colno = col;
	newnodefun->val = data;
	newnodefun->rp = NULL;
	newnodefun->cp = NULL;
	
	return newnodefun;
	
}
void main()
{

		void insert(Node ** ,Node **  , int n );
		void add(Node ** ,Node ** , Node **  , int n );
		void display( Node ** , Node ** , Node ** , int n );
		
		Node **top , **top1 , **top2;
		int  n ;
		
		top=( Node **)malloc(sizeof( Node **));
		top1=( Node **)malloc(sizeof( Node **));
		top2=( Node **)malloc(sizeof( Node **));
		
		*(top)=NULL;
		*(top1)=NULL;
		*(top2)=NULL;
		
		printf("\n Enter Size :-");
		scanf("%d",&n);
		
		insert(top ,top1 , n);
		add(top ,top1 , top2 , n);
		display(top , top1 , top2 , n);
}
void insert( Node **top , Node **top1 , int n )
{
	Node *curr,*pre , *prev;
	Node *curr1,*pre1 , *prev1;
	Node *newnode ;
	int i , j , data;
	
	//newnode=( Node *)malloc(sizeof( Node *));
	
	curr = *(top);
	pre = NULL;
	
	curr1 = *(top1);
	pre1 = NULL;
	
	// Insert First Linked List structure Value
	printf("\n Insert First Linked List structure Value");
	for(i=0 ; i<n ; i++)
	{
		for(j=0 ; j<n ; j++)
		{
			printf("\n Enter First Matrix Value :- ");
			scanf("%d",&data);
		
			newnode = nodefunction(i , j , data);
			// First Row First Column Value Insert
			if(curr == NULL)
			{
				curr = newnode;
				*(top)=curr;
			
			}
			else
			{
			
				if(i!=0 && j==0)
				{
					// Second Row and First Column Value Insert
					curr = prev;
					curr->rp = newnode;
					
				}
				else if(i!=0 && j!=0)
				{
					// Without First Row and Without First Column Value Insert
					pre = curr->rp;
					curr = curr->cp;
					pre->cp = newnode;
					curr->rp = newnode;
					
				}
				else 
				{
					// First Row and without First Column Value Insert
					pre = curr;
					curr = newnode;
					pre->cp = curr;
					pre = pre->cp ;
				
				}
			}
		
		}
		
		if(i==0)
		{
			// First time define row pointer
			prev = *(top);
		}
		else
		{
			// every time define row pointer
			prev = prev->rp;
			curr = curr->rp;
			curr = prev;
		}
		
	}
	
	//Insert Second Linked List structure Value
	printf("\n Insert Second Linked List structure Value");	
	for(i=0 ; i<n ; i++)
	{
		for(j=0 ; j<n ; j++)
		{
			printf("\n Enter Second Matrix Value :- ");
			scanf("%d",&data);
		
			newnode = nodefunction(i , j , data);
			// First Row First Column Value Insert
			if(curr1 == NULL)
			{
				curr1 = newnode;
				*(top1)=curr1;
			
			}
			else
			{
			
				if(i!=0 && j==0)
				{
					// Second Row and First Column Value Insert
					curr1 = prev1;
					curr1->rp = newnode;
					
				}
				else if(i!=0 && j!=0)
				{
					// Without First Row and Without First Column Value Insert
					pre1 = curr1->rp;
					curr1 = curr1->cp;
					pre1->cp = newnode;
					curr1->rp = newnode;
					
				}
				else 
				{
					// First Row and without First Column Value Insert
					pre1 = curr1;
					curr1 = newnode;
					pre1->cp = curr1;
					pre1 = pre1->cp ;
				
				}
			}
		
		}
		
		if(i==0)
		{
			// First time define row pointer	
			prev1 = *(top1);
		}
		else
		{
			// every time define row pointer
			prev1 = prev1->rp;
			curr1 = curr1->rp;
			curr1 = prev1;
		}
		
	}
	
}
void add(Node ** top , Node **top1 , Node **top2 , int n )
{
	int i , j , add;
	Node *curr , *pre , *prev;
	Node *curr1 , *pre1 , *prev1;
	Node *curr2 , *pre2 , *prev2;
	Node *newnode ;
	
	//newnode=( Node *)malloc(sizeof( Node *));
	
	printf("\n Addition");
	//First Mat 
	curr = *(top);
	pre = *(top);
	
	//Second Mat 
	curr1 = *(top1);
	pre1 = *(top1);
	
	//Add Mat 
	curr2 = *(top2);
	pre2 = *(top2);
	
	
		printf("\n \n fghj");
		//Display First Matrix
		printf("\n Insert Second Linked List structure Value");	
		for(i=0 ; i<n ; i++)
		{
			for(j=0 ; j<n ; j++)
			{
				add = curr->val + curr1->val;
				printf("\n %d",add);
				newnode = nodefunction(i , j , add);
				printf("\n \n newnode");
				// First Row First Column Value Insert
				if(curr2 == NULL)
				{
					curr2 = newnode;
					*(top2)=curr2;
				
				}
				else
				{
				
					if(i!=0 && j==0)
					{
						// Second Row and First Column Value Insert
						curr2 = prev2;
						curr2->rp = newnode;
						
					}
					else if(i!=0 && j!=0)
					{
						// Without First Row and Without First Column Value Insert
						prev2 = curr2->rp;
						curr2 = curr2->cp;
						prev2->cp = newnode;
						curr2->rp = newnode;
						
					}
					else 
					{
						// add First Row and without First Column Value Insert
						pre2 = curr2;
						curr2 = newnode;
						pre2->cp = curr2;
						pre2 = pre2->cp ;
					
					}
				}
			
			}
			
			if(i==0)
			{
				// add First time define row pointer	
				prev2 = *(top2);
			}
			else
			{
				// add every time define row pointer
				prev2 = prev2->rp;
				curr2 = curr2->rp;
				curr2 = prev2;
			}
			
		}
}
void display( Node ** top , Node **top1 , Node **top2 , int n )
{
	int i , j;
	Node *curr , *pre;
	Node *curr1 , *pre1;
	Node *curr2 , *pre2;
	
	//First Mat 
	curr = *(top);
	pre = *(top);
	
	//Second Mat 
	curr1 = *(top1);
	pre1 = *(top1);
	
	//Add Mat 
	curr2 = *(top2);
	pre2 = *(top2);
	
		printf("\n \n");
		//Display First Matrix
		printf("\n Display First Matrix Value :..");
		for(i=0 ; i<n ; i++)
		{
			for(j = 0 ; j<n ; j++)
			{
				printf("\t [ %d | %d | %d ]" , curr->rowno , curr->colno , curr->val);
				curr = curr->cp;
			}
			printf(" \n");
			pre = pre->rp;
			curr = pre;
		}
		
		printf("\n \n");
		//Display Second Matrix
		printf("\n Display Second Matrix Value :..");
		for(i=0 ; i<n ; i++)
		{
			for(j = 0 ; j<n ; j++)
			{
				printf(" \t [ %d | %d | %d ]" , curr1->rowno , curr1->colno , curr1->val);				
				curr1 = curr1->cp;
			}
			printf(" \n");
			pre1 = pre1->rp;
			curr1 = pre1;
		}
		
		//Display Addition Value
		printf("\n Display Addition Value :..");
		for(i=0 ; i<n ; i++)
		{
			for(j = 0 ; j<n ; j++)
			{
				printf(" \t [ %d | %d | %d ]" , curr2->rowno , curr2->colno , curr2->val);				
				curr2 = curr2->cp;
			}
			printf(" \n");
			pre2 = pre2->rp;
			curr2 = pre2;
		}

}
