//Pro :-12. Write  menu driven program to implement adjacency list representation of graph 1)  Create 2) BFS 3) DFS.
#include<stdio.h>
#include<string.h>

void main()
{
	void bfs_insert(int [10][10] , int n);
	void bfs_path(int [10][10] , int n);
	void dfs_path(int a[10][10], int n, int visited[10], int vertex);
	
	int a[10][10] , n , i , choice ,vertex=0;
	int visited[10];
	
    printf("\n Enter Size: ");
    scanf("%d", &n);
	
	bfs_insert(a,n);
	bfs_path(a,n);
					
	
	for ( i = 0; i < n; i++) 
	{
		visited[i] = 0;
	}
	dfs_path(a, n, visited, vertex);
			

}
void bfs_insert(int a[10][10] , int n)
{
	int i , j;
	printf("\n Enter only 0 or 1 Value ... \n");
	
	for(i=0 ; i<n ; i++)
	{
		for(j=0 ; j<n ; j++)
		{
			printf(" Enter Value for (%d, %d): ", i, j);
			scanf("%d",&a[i][j]);
		}
		printf("\n");
	}
}
void bfs_path(int a[10][10] , int n)
{
	int i , j , k;
	int visited[k];
	j=0;
	
	for(i=0 ; i<n ; i++)
	{
		visited[i]=0;
	}
	
	visited[j]=1;
	printf("\nBFS Path :-> %d ",j);
	
	for(i=0 ; i<n ; i++)
	{
		for(k=0 ; k<n ; k++)
		{
			if( a[i][k]==1 && visited[k]==0)
			{
				visited[k]=1;
				printf("\n :-> %d",k);
			}
		}
	}
	printf("\n");
}
void dfs_path(int a[10][10], int n, int visited[], int vertex)
{
    int i;

    printf(" :-> %d ", vertex);
    visited[vertex] = 1;

    for (i = 0; i < n; i++)
    {
        if (a[vertex][i] == 1 && visited[i]==0)
        {
            dfs_path(a, n, visited, i);
        }
    }
}
