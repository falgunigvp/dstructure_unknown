//Pro :-1. stack using Stack list
#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node *next;
};
 
void main()
{
	void insert_link(struct node **, int );
	void delete_link(struct node **);
	void display_link(struct node **);
	struct node **top;
	int val;
	int choice;
	top=(struct node **)malloc(sizeof(struct node *));
	*(top)=NULL;
	
	
	while(1)
	{
		printf("\n 1.Insert :- ");
		printf("\n 2.delete :- ");
		printf("\n 3.display :- ");
		printf("\n Enter choice :- ");
		scanf("%d",&choice);
		printf("\n ");
		switch(choice)
		{
		case 1:{
					printf("\n Enter value :-");
					scanf("%d",&val);
					insert_link(top,val);
					break;
			   }
		case 2:{
					delete_link(top);	
					break;
			   }
		case 3:{
					display_link(top);
					break;
			   }
		case 4:{
				exit(1);  
				  break;
				}
		}
	}
}
void insert_link(struct node **top, int val)
{
	struct node *newnode;
	newnode=(struct node *)malloc(sizeof(struct node));
	
	newnode->data=val;
	newnode->next=*(top);
	*(top)=newnode;

	printf("\ndata %d :- ",newnode->data);
	printf("\n ");
}
void delete_link(struct node **top)
{
	struct node *curr;
	
	curr = *(top);
	if( curr == NULL)
	{
		printf("\n Linked List is  Empty ");
	}
	else
	{
        printf("\n Delete Value is :- %d ",curr->data);
		*(top) = curr->next;
		free(curr);
		printf("\n ");
	}
}
void display_link(struct node **top)
{
	struct node *current;
	current=*(top);
	
	if(current==NULL)
		printf("\n Linked List is Empty");
	else
	{
		while(current!=NULL)
		{
			printf("\n Display Value is %d ",current->data);
			current=current->next;
		}
	}
	printf("\n ");
}
