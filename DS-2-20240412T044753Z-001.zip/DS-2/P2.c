//Pro :-2 Linked List Queue
#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node *next;
};

void main()
{
	void insert_linked(struct node **, int );
	void delete_linked(struct node ** );
	void display_linked(struct node ** );
	
	struct node **top;
	int val;
	int choice;
	
	top=(struct node ** )malloc(sizeof(struct node *));
	
	*(top)=NULL;
	
	while(1)
	{
		printf("\n 1.Insert Value ...");
		printf("\n 2.Delete Value ...");
		printf("\n 3.Display Value ...");
		printf("\n 4.Exit ...");
		printf("\n Enter choice :- ");
		scanf("%d",&choice);
		printf("\n ");
		switch(choice)
		{
		case 1:{
					printf("\n Enter value :-");
					scanf("%d",&val);
					insert_linked(top,val);
					break;
			   }
		case 2:{
					delete_linked(top);	
					break;
			   }
		case 3:{
					display_linked(top);
					break;
			   }
		case 4:{
				  exit(1);
				  break;
				}
		}
	}
}

void insert_linked(struct node **top , int val)
{
	struct node *newnode;
	struct node *current;
	
	newnode=(struct node *)malloc(sizeof(struct node *));
	current=*(top);
	
	newnode->data=val;
	newnode->next=NULL;

	printf("\nData  value %d",newnode->data);
	if(current==NULL)
	{
		*(top)=newnode;
	}
	else
	{
		while(current->next!=NULL)
		{
			current=current->next;
		
		}
		current->next=newnode;
	}
	
}
void delete_linked(struct node **top )
{
	struct node *curr;
	curr=*(top);
	if(curr==NULL)
	{
		printf("\n Linked List is  Empty ");
	}
	else
	{
		printf("\n Delete Value is :- %d ",curr->data);
		*(top)=curr->next;
			
		printf("\n ");
		free(curr);
	}
	
}
void display_linked(struct node **top )
{

		struct node *current;
		current=*(top);
		
		if(current==NULL)
			printf("\n Linked List is Empty");
		else
		{
			while(current!=NULL)
			{
				printf("\n Display Value is %d ",current->data);
				current=current->next;
			}
		}
		printf("\n ");
}
