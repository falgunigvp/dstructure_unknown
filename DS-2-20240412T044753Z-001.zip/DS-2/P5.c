//Pro :-5. Write a menu driven program to implement circle  1) Insert 2) Delete 3) Display.
#include<stdio.h>
#include<conio.h>
#include<stdlib.h>

#define max 10
int q[max];

void main()
{
	
	void insert_circ_que( int * , int * , int );
	int delete_circ_que( int * , int *  ); 
	void display_circ_que( int *,int *);
	
	int *front , *rear;
	
	int ele,choice , temp_val;
	
	front= (int *)malloc(sizeof(int *));
	rear = (int *)malloc(sizeof(int *));
	
	
	*(front) = -1;
	*(rear) = -1;
	
	while(1)
	{
		printf("\n 1.Insert Value :-  ");
		printf("\n 2. Delete  Value :- ");
		printf("\n 3. Display Value :-");
		printf("\n 4. Exit Program :-");
		
		printf("\n Enter Your Choice :- ");
		scanf("%d",&choice);
		
		switch(choice)
		{
			case 1:{
				printf("\n Enter Front Value :");
				scanf("%d",&ele);
				insert_circ_que(front , rear ,ele);
				break;
			}
			case 2:{
				temp_val=delete_circ_que(front , rear );
				printf("Delete Value is :- %d",temp_val);
				break;
			}
			case 3:{
				display_circ_que(front , rear );
				break;
			}
			
			case 4:{
				exit(1);
				break;
			}
			
		}
		
	}
	
}

void insert_circ_que( int *front, int * rear, int ele)
{
	int choice;
	
	if(*(front)==-1 && *(rear)== -1)
	{
		printf("\n if ");
		*(front) =*(rear)=0;
		q[*(front)]=ele;		
	}
	else
	{
		if((*(front)==max-1 && *(rear)==0) || (*(rear) - *(front) )==1)
		{
			printf("\n Circle Queue is Full...");
		}
		else
		{
			if( (*(front)==max-1 && *(rear)!=0))
			{
				printf("\n if if");
				// && *(rear)=*(front)!=1
				*(front)=0;
				q[*(front)]=ele;	
			}
			else
			{
				printf("\n if else");
				*(front)=*(front)+1;
				q[*(front)]=ele;
			}
		}
	}
}
int delete_circ_que( int * front ,int * rear)
{
	int choice , temp ;
	if(*(front)==-1 && *(rear)== -1)
	{
		printf("\n Circle Queue is Empty...");
		return -1;
	}
	else
	{
		if(*(rear)==max-1 && *(front)!=max-1)
		{
			*(rear)=0;
			temp = q[*(rear)];
		}	
		else
		{
			if(*(rear)==*(front))
			{
				temp = q[*(rear)];
				*(front) =*(rear)=-1;
			}
			else
			{
				temp = q[*(rear)];
				*(rear) =*(rear) + 1;
			}
		}
	}
	
	return temp;
	
}
void display_circ_que( int * front , int *rear)
{
	int choice ,i,j ;
	if(*(front)==-1 && *(rear)== -1)
	{
		printf("\n Double Queue is Empty...");
	}
	else
	{
		if(*(rear)<= *(front))
		{
			for(i=*(rear) ; i<=*(front) ; i++)
			{
				printf("\n Display Value is :- %d",q[i]);
			}
		}
		else
		{
			printf("\n if else");
			for(i=*(rear) ; i< max ; i++)
			{
				printf("\n Display Value is :- %d",q[i]);
			}
			for(i=0 ; i<= *(front) ; i++)
			{
				printf("\n Display Value is :- %d",q[i]);
			}
		}
	}
	
}
