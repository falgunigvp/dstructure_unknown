//Pro :-15. Write  menu driven program to implement Quick Sort.
#include<stdio.h>
#include<stdlib.h>

void main()
{
	void insert_qs(int [10] , int , int );
	void quick_sort(int [10]  ,int  , int );
	void print_qs(int [10] , int );
	
	int qs[10];
	int i , no , val ;
	
	printf("\n How many Size ... ");
	scanf("%d",&no);

	insert_qs(qs , val , no);
	quick_sort(qs  , 0 , no);
	print_qs(qs  , no);
	
}

void insert_qs(int qs[10] , int val , int no )
{
	int i ;
	for(i=0 ; i<no ; i++)
	{
		printf("\n Enter Sorting Value ... ");
		scanf("%d",&qs[i]);
	}
}

void quick_sort(int qs[10] , int first , int last )
{
	int i , j , pivat , temp;
	
	if(first < last)
	{
		i = first ;
		pivat = first;
		j = last;
		while(i<j)
		{
			while(qs[i]<=qs[pivat] && i<last)
			{
				i++;
			}
			while(qs[j]>qs[pivat])
			{
				j--;
			}
			if(i<j)
			{
				temp = qs[i];
				qs[i] = qs[j];
				qs[j] = temp;
			}
		}
		
		temp = qs[pivat];
		qs[pivat] = qs[j];
		qs[j] = temp;
		
		quick_sort(qs , first ,j-1);
		quick_sort(qs , j+1 , last);
	}
}

void print_qs(int qs[10]  , int no )
{
	int i ;
	for(i=0 ; i<no ; i++)
	{
		printf("\n  Value ... %d",qs[i]);
	}
}
