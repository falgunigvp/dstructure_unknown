//Pro :-16. Write  menu driven program to implement Radix Sort.
#include<stdio.h>
void main()
{

	void read(int a[10] ,int n );
	int largest(int a[10],int n);
	void radix_sort(int a[10],int n);
	void display(int a[10],int n);
	
	int a[10],i,n;

	printf("Enter the Number :.. ");
	scanf("%d",&n);

	read(a,n);
	largest(a,n);
	radix_sort(a,n);
	display(a,n);

}
void read(int a[10] , int n)
{
	int i;
	
	for(i=0 ; i< n; i++)
	{
		printf("\n Enter element :");
		scanf("%d",&a[i]);
	}
}
int largest(int a[10],int n){

	int large,i;

	for(i=0;i<n;i++){
		
		if(a[i]>large)
		{
			large=a[i];
		}
		return large;
	}
}

void radix_sort(int a[10],int n){
	
	int add[10][10],add_cnt[10];
	int i,j,k , l ,cnt=0 ;
	int rem,div=1,large;
	
	large=largest(a,n);

	while(large>0)
	{
		
		cnt++;
		large=large/10;
	}

	for(l=0;l<cnt;l++)
	{
		
		for(i=0;i<10;i++)
		{
			add_cnt[i]=0;
		}

		for(i=0;i<10;i++)
		{
			
			rem=(a[i]/div)%10;
			add[rem][add_cnt[rem]]=a[i];
			add_cnt[rem] = add_cnt[rem] + 1;
		}
		i=0;

		for(k=0;k<10;k++)
		{
			for(j=0;j<add_cnt[k];j++){
				
				a[i]=add[k][j];
				i++;
			}
		}
		div = div *10;
	}
}
void display(int a[10] , int n)
{
	int i;
	for(i=0;i<n;i++){
		
		printf(" %d ",a[i]);
	}
}
