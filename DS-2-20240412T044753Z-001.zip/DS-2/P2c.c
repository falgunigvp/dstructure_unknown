//Pro :-2 Linked List Queue
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct node
{
	char name[100];
	struct node *next;
};

void main()
{
	void insert_linked(struct node **, char [100] );
	void delete_linked(struct node ** );
	void display_linked(struct node ** );
	
	struct node **top;
	char name[100];
	int choice;
	
	top=(struct node ** )malloc(sizeof(struct node *));
	
	*(top)=NULL;
	
	while(1)
	{
		printf("\n 1.Insert Value ...");
		printf("\n 2.Delete Value ...");
		printf("\n 3.Display Value ...");
		printf("\n 4.Exit ...");
		printf("\n Enter choice :- ");
		scanf("%d",&choice);
		printf("\n ");
		switch(choice)
		{
		case 1:{
					printf("\n Enter value :-");
					scanf("%s",name);
					insert_linked(top,name);
					break;
			   }
		case 2:{
					delete_linked(top);	
					break;
			   }
		case 3:{
					display_linked(top);
					break;
			   }
		case 4:{
				  exit(1);
				  break;
				}
		}
	}
}

void insert_linked(struct node **top , char name[100])
{
	struct node *newnode;
	struct node *current;
	
	newnode=(struct node *)malloc(sizeof(struct node *));
	current=*(top);
	
	strcpy(newnode->name,name);
	//newnode->data=val;
	newnode->next=NULL;

	printf("\nData  value %s",newnode->name);
	if(current==NULL)
	{
		*(top)=newnode;
	}
	else
	{
		while(current->next!=NULL)
		{
			current=current->next;
		
		
		}
		current->next=newnode;
	}
	
}
void delete_linked(struct node **top )
{
	struct node *curr;
	curr=*(top);
	if(curr==NULL)
	{
		printf("\n Linked List is  Empty ");
	}
	else
	{
		printf("\n Delete Value is :- %s ",curr->name);
		*(top)=curr->next;
			
		printf("\n ");
		free(curr);
	}
	
}
void display_linked(struct node **top )
{

		struct node *current;
		current=*(top);
		
		if(current==NULL)
			printf("\n Linked List is Empty");
		else
		{
			while(current!=NULL)
			{
				printf("\n Display Value is %s ",(current->name));
				current=current->next;
			}
		}
		printf("\n ");
}
