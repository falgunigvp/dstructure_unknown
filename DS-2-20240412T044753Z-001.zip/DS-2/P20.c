//Pro:-20. Write  menu driven program to implement Priority Linked List of 1)  insert 2) delete 3)  Display.
#include<stdio.h>
#include<stdlib.h>
struct node
{
	
	int data;
	struct node *next;
};
 
void main()
{
	void insert_prio_link(struct node **,struct node **, int );
	void delete_prio_link(struct node **,struct node ** );
	void display_prio_link(struct node **,struct node **);
	
	struct node **top1,**top2;
	int val;
	int choice;
	
	top1=(struct node **)malloc(sizeof(struct node *));
	top2=(struct node **)malloc(sizeof(struct node *));
	*(top1)=NULL;
	*(top2)=NULL;
	
	
	while(1)
	{
		printf("\n 1.Insert :- ");
		printf("\n 2. delete :- ");
		printf("\n 3.display :- ");
		printf("\n 4.Exit :- ");
		printf("\n Enter choice :- ");
		scanf("%d",&choice);
		printf("\n ");
		switch(choice)
		{
		case 1:{
					printf("\n Enter value :-");
					scanf("%d",&val);
					insert_prio_link(top1,top2,val);
					break;
			   }
		
		case 2: {
					delete_prio_link(top1,top2);
					break;
				}  
		case 3:{
					display_prio_link(top1,top2);
					break;
			   }
		case 4:{
				  exit(1);
				  break;
				}
		}
	}
}
void insert_prio_link(struct node **top1,struct node **top2, int val)
{
	struct node *newnode,*curr1,*curr2;
	newnode=(struct node *)malloc(sizeof(struct node));
	curr1 = *(top1);
	curr2 = *(top2);

	newnode->data = val;

	if(val>60)
	{
		if(curr1==NULL)
		{
			newnode->next = *(top1);
			*(top1) = newnode ; 
		}
		else
		{
			while(curr1->next!=NULL)
			{
				curr1 = curr1->next;
			}
			newnode->next = NULL;
			curr1->next = newnode;
		}
	}
	else
	{
		if(curr2==NULL)
		{
			newnode->next = *(top2);
			*(top2) = newnode ; 
		}
		else
		{
			while(curr2->next!=NULL)
			{
				curr2 = curr2->next;
			}
			newnode->next = NULL;
			curr2->next = newnode;
		}
	}
	
	printf("\n");
}

void delete_prio_link(struct node **top1,struct node **top2)
{

		struct node *curr1,*curr2;
		
		curr1 = *(top1);
		curr2 = *(top2);
	
		if(curr1 == NULL && curr2 == NULL)
		{
			printf("\n Priority Link List is Empty");
		}
		else if(curr1 != NULL)
		{
				printf("\n First Prio delete %d",curr1->data);
			//	curr1 = curr1->next;
				*(top1)=curr1->next;
				free(curr1);
			
		}
		else
		{
				printf("\n Second Prio delete %d",curr2->data);
			//	curr1 = curr1->next;
				*(top2)=curr2->next;
				free(curr2);
		}
		
}
void display_prio_link(struct node **top1,struct node **top2)
{
	struct node *curr1,*curr2;
		
	curr1 = *(top1);
	curr2 = *(top2);
	
	
		if(curr1 == NULL && curr2 == NULL)
		{
			printf("\n Priority Link List is Empty");
		}
		else 
		{
			while(curr1->next != NULL)
			{
				printf("\n First Prio Display %d",curr1->data);
				curr1 = curr1->next;
			}
			printf("\n First Prio Display %d",curr1->data);
			
			while(curr2->next != NULL)
			{
				printf("\n Second Prio Display %d",curr2->data);
				curr2 = curr2->next;
			}
			printf("\n Second Prio Display %d",curr2->data);
		}
	
	printf("\n ");
}
